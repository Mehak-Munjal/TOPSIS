from setuptools import setup
setup(name="TOPSIS_Mehak_101983050",
version="0.1",
description="Assignment06",
url="https://github.com/Mehak-Munjal/TOPSIS",
author="Mehak",
packages=['TOPSIS_Mehak_101983050'],
install_requires=['pandas'])
